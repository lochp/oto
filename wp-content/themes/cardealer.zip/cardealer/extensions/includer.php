<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php

include_once TMM_EXT_PATH . '/demo/index.php';
include_once TMM_EXT_PATH . '/sliders/index.php';
include_once TMM_EXT_PATH . '/sliders/items/flex/index.php';
include_once TMM_EXT_PATH . '/cardealer/index.php';
include_once TMM_EXT_PATH . '/authentication/index.php';
include_once TMM_EXT_PATH . '/plugin_activation/class-tgm-plugin-activation.php';
include_once TMM_EXT_PATH . '/plugin_activation/plugin_update_checker.php';

