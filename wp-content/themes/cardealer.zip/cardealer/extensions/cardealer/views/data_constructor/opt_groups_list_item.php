<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<a href="#" data-group-index="<?php echo $index ?>" data-group-name="<?php echo $name ?>" class="show_group_data_link"><?php echo $name ?></a>
<a class="edit show_group_data_link" data-group-index="<?php echo $index ?>" title="<?php _e("Edit", 'cardealer') ?>" href="#"></a>
