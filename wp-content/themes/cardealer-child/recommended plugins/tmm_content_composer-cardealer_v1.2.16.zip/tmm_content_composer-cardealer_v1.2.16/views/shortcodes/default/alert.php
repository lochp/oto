<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<p class="<?php echo $type ?>"><?php echo $content ?><a href="#" class="alert-close"></a></p>