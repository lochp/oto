<?php
//echo do_shortcode('[woocommerce_checkout]');